#Candy jQuery UI lightness Theme plugin

This plugin replaces the default theme with the jQuery UI lightness Theme. (http://jqueryui.com/)

##Usage
To enable jQuery UI lightness Theme you have to include its stylesheet:

```html
<link rel="stylesheet" type="text/css" href="candy/plugins/jquery-ui/ui-lightness/css/ui-lightness.css" />
```