# Join Plugin
A plugin to join public rooms.

Just Type `/join room [password]` to join a room.

## Usage
Include the JavaScript file::

```HTML
<script type="text/javascript" src="candyshop/join/candy.js"></script>
```

To enable the Join Plugin, just add one of the ´init´ methods to your bootstrap:

```JavaScript
CandyShop.Join.init();
```
